const helloWorld = new Vue({
    el: '#helloVue',
    data: {
        title: 'HELLO WORLD!!!!!',
        message: 'This is my first Vue template!'
    }
});

const example = new Vue({
    el: '#example',
    data: {
        title: 'Hello',
        message: 'This is your daily cat-firmation!',
        name: 'Chewie'
    }
});