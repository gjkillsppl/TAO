const helloWorld = new Vue({
    el: '#helloVue',
    data: {
        title: "HELLO WORLD!!!!!",
        message: "This is my first Vue template!"
    }
});